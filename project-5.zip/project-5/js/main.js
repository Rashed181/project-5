// nav toggle

$(".dropdownItem").click(function(){
    $(".dropdown-content").toggle();
  });

// owl carousel slider
$('.owl-carousel').owlCarousel({
    loop:true,
    margin: 10,
    nav:true,
    autoplay:true,
    autoplayTimeout:1500,
    autoplayHoverPause:true,
    navText: ['Prev', 'Next'],
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
});

// counter

$('.count').each(function () {
    $(this).prop('Counter',0).animate({
        Counter: $(this).text()
    }, {
        duration: 4000,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
        }
    });

});

$(document).ready(function() {
    $('.popup-img').magnificPopup({
      type:'image'
      
    });
  });
  
  $(document).ready(function() {
    $('.gallery-pic').magnificPopup({
      type:'image',
      gallery:{
        enabled:true
      }
      
    });
  });

//MIXITUP (PORTFOLIO-SECTION)

$(document).ready(function(){
    
    var mixer = mixitup('.mixing')
});

/*Scroll to top when arrow up clicked BEGIN*/
$(window).scroll(function() {
    var height = $(window).scrollTop();
    if (height > 100) {
        $('#back2Top').fadeIn();
    } else {
        $('#back2Top').fadeOut();
    }
});
$(document).ready(function() {
    $("#back2Top").click(function(event) {
        event.preventDefault();
        $("html, body").animate({ scrollTop: 0 }, "slow");
        return false;
    });

});

 /*Scroll to top when arrow up clicked END*/
// aos js
 $(document).ready(function() {
    AOS.init({
      offset: 300,
      duration: 1000
    });
});
